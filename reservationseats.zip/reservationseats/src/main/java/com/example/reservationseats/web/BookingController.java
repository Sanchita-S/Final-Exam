package com.example.reservationseats.web;

import com.example.reservationseats.entities.Seat;
import com.example.reservationseats.entities.Transaction;
import com.example.reservationseats.repositories.SeatRepository;
import com.example.reservationseats.repositories.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.ui.ModelMap;

import java.util.List;
import java.util.Optional;

@SessionAttributes({"error"})
@Controller
public class BookingController {

    @Autowired
    private SeatRepository seatRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @GetMapping("/home")
    public String showDetailsPage(Model model) {
        List<Seat> seats = seatRepository.findAll();
        List<Transaction> transactions = transactionRepository.findAll();
        model.addAttribute("seats", seats);
        model.addAttribute("transactions", transactions);
        model.addAttribute("seats_remaining", seats.size() - transactions.size());
        return "booking-details";
    }
    @PostMapping("/reserve")
    public String reserveSeat(Model model, Transaction transaction, BindingResult bindingResult, ModelMap mm, HttpSession session) {
        Seat seat = seatRepository.findBySeatNumber(transaction.getSeatNumber());
        if (seat == null || seat.isBooked()) {
            mm.put("error", "Seat is not available.");
        } else {
            seat.setBooked(true);
            seatRepository.save(seat);
            transactionRepository.save(transaction);
        }
        return "redirect:/home";
    }
//    @GetMapping("/delete")
//    public String delete(Long id){
//        Transaction transaction =transactionRepository.findByTransactionID(id);
//        transactionRepository.deleteById(id);
//        seatRepository.save(seatRepository.findBySeatNumber(transaction.getSeatNumber()).setBooked(false));
//        return "redirect:/home";
//    }
    @PostMapping("/editTransaction")
    public String editTransaction(Model model, Transaction transaction, BindingResult bindingResult, ModelMap mm, HttpSession session) {
        if (transactionRepository.findByTransactionID(transaction.getId()) == null) {
            mm.put("error", "Transaction is not available.");
            return "redirect:/home";
        }

        Seat seat = seatRepository.findBySeatNumber(transaction.getSeatNumber());
        if (seat == null || seat.isBooked()) {
            mm.put("error", "Seat is not available.");
        } else {
            seat.setBooked(true);
            seatRepository.save(seat);
            transactionRepository.save(transaction);
        }
        return "redirect:/home";
    }
    }


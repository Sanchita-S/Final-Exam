package com.example.reservationseats.entities;

import jakarta.persistence.*;

import java.util.Date;


@Entity
public class Transaction {


        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;
        private Date date;
        private String seatNumber;
        private Long seatId;
        private String customerName;

        // Getters and Setters
        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public Long getSeatId() {
            return seatId;
        }
    public String getSeatNumber() {
        return seatNumber;
    }

        public void setSeatId(Long seatId) {
            this.seatId = seatId;
        }


    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public String getCustomerName() {
            return customerName;
        }

        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }

        public Date getDate() {
            return date;
        }

        public void setDate(Date date) {
            this.date = date;
        }
    }



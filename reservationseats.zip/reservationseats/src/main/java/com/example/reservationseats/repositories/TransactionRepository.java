package com.example.reservationseats.repositories;

import com.example.reservationseats.entities.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    Optional<Transaction> findByTransactionID(long transactionId);
    List<Transaction> findAll();

}

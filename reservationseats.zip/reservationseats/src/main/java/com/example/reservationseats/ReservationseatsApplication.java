package com.example.reservationseats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservationseatsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservationseatsApplication.class, args);
	}

}
